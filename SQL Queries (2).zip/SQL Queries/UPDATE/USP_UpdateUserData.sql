
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables User 
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateUserData
(
	@UserId varchar(50),	
	@UserName varchar(50),
	@Password varchar(255),
	@RoleId int,
	@DepartmentId varchar(50),
	@DateOfJoining date,
	@DateOfBirth date,
	@EmailId varchar(50),
	@Phonenumber varchar(50),
	@Address varchar(255),
	@SecretQuestion varchar(255)
)
AS
BEGIN
	BEGIN TRY
		UPDATE [User] SET
		[UserName]= ISNULL(@UserName,UserName),
		[Password]=ISNULL(@Password,Password),
		[RoleId]=ISNULL(@RoleId,RoleId),
		[DepartmentId]=ISNULL(@DepartmentId,DepartmentId),
		[DateOfJoining]=ISNULL(@DateOfJoining,DateOfJoining),
		[DateOfBirth]=ISNULL(@DateOfBirth,DateOfBirth),
		[EmailId]=ISNULL(@EmailId,EmailId),
		[Phonenumber]=ISNULL(@Phonenumber,Phonenumber),
		[Address]=ISNULL(@Address,Address),
		[SecretQuestion]=ISNULL(@SecretQuestion,SecretQuestion)
		WHERE [UserId] = @UserId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO