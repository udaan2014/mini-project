

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from Comment table
-- ==============================================================================================================    
CREATE PROCEDURE USP_GetCommentData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [UserId],
				[RegulationId],
				[Acceptance],
				[Description],
				[DateOfCreation],
				[DateOfModification] 
		FROM [Comment]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   