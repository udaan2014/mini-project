
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from Role table
-- ==============================================================================================================    
CREATE PROCEDURE USP_GetRoleData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [RoleId],
				[RoleType],
				[Description] 
		FROM [Role]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   