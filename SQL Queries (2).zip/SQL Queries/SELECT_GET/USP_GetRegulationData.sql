
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from regulation table
-- ==============================================================================================================    
CREATE PROCEDURE USP_GetRegulationData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [RegulationId],
				[RegulationName],
				[Description],
				[Status],
				[DateOfCreation],
				[DateOfModification] 
		FROM [Regulation]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   