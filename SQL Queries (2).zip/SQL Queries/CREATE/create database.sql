-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tricare database
-- ==============================================================================================================
CREATE DATABASE TricareDatabase
GO

USE TricareDatabase
GO
