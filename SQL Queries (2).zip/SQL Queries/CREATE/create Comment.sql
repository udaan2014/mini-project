-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables Comment
-- ==============================================================================================================
CREATE TABLE [Comment]
(
	[UserId] varchar(50),
	[RegulationId] int,
	[Acceptance] bit,
	[Description] varchar(255),
	[DateOfCreation] date DEFAULT GETDATE(),
	[DateOfModification] date DEFAULT GETDATE(),
	CONSTRAINT PK_Comment_UserId_RegulationId PRIMARY KEY ([UserId],[RegulationId])
)
