
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Table RegulationDepartemnt
-- ==============================================================================================================

CREATE TABLE [RegulationDepartment]
(
	[RegulationId] int,
	[DepartmentId] varchar(50),
	[EmployeeAccess] bit,
	CONSTRAINT PK_RegulationDepartment_RegulationId_DepartmentId PRIMARY KEY ([RegulationId],[DepartmentId])
)
GO