
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables Role
-- ==============================================================================================================
CREATE TABLE [Role]
(
	[RoleId] int IDENTITY(1,1),
	[RoleType] varchar(50),
	[Description] varchar(255),
	CONSTRAINT PK_Role_RoleId PRIMARY KEY ([RoleId])
)
GO