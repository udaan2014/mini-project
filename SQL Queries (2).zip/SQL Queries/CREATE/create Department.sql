
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables:  Department
-- ==============================================================================================================
CREATE TABLE [Department]
(
	[DepartmentId] varchar(50),
	[DepartmentName] varchar(50),
	[DateOfCreation] date DEFAULT GETDATE(), 
	CONSTRAINT PK_Department_DepartmentId PRIMARY KEY ([DepartmentId])
)
GO
