
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables User 
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateUser
(
	@UserId varchar(50),	
	@UserName varchar(50),
	@Password varchar(255),
	@RoleId int,
	@DepartmentId varchar(50),
	@DateOfJoining date,
	@DateOfBirth date,
	@EmailId varchar(50),
	@Phonenumber varchar(50),
	@Address varchar(255),
	@SecretQuestion varchar(255)
)
AS
BEGIN
	BEGIN TRY
		UPDATE [User] SET
		[UserName]= ISNULL(@UserName,UserName),
		[Password]=ISNULL(@Password,Password),
		[RoleId]=ISNULL(@RoleId,RoleId),
		[DepartmentId]=ISNULL(@DepartmentId,DepartmentId),
		[DateOfJoining]=ISNULL(@DateOfJoining,DateOfJoining),
		[DateOfBirth]=ISNULL(@DateOfBirth,DateOfBirth),
		[EmailId]=ISNULL(@EmailId,EmailId),
		[Phonenumber]=ISNULL(@Phonenumber,Phonenumber),
		[Address]=ISNULL(@Address,Address),
		[SecretQuestion]=ISNULL(@SecretQuestion,SecretQuestion)
		WHERE [UserId] = @UserId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO



-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables Department
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateDepartment
(
	@DepartmentId varchar(50),
	@DepartmentName varchar(50),
	@DateOfCreation date
)
AS
BEGIN
	BEGIN TRY
		UPDATE [Department] SET
		[DepartmentName]= ISNULL(@DepartmentName,DepartmentName),
		[DateOfCreation]=ISNULL(@DateOfCreation,DateOfCreation)		
		WHERE [DepartmentId] = @DepartmentId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO


-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables Role
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateRole
(
	@RoleId int,
	@RoleType varchar(50),
	@Description varchar(255)
)
AS
BEGIN
	BEGIN TRY
		UPDATE [Role] SET
		[RoleType]=ISNULL(@RoleType,RoleType),
		[Description]= ISNULL(@Description,Description)		
		WHERE [RoleId] = @RoleId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO


-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables Regulation
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateRegulation
(
	@RegulationId int,
	@RegulationName varchar(50),
	@Description varchar(255),
	@Status varchar(50),
	@DateOfCreation date,
	@DateOfModification date
)
AS
BEGIN
	BEGIN TRY
		UPDATE [Regulation] SET
		[RegulationName]=ISNULL(@RegulationName,RegulationName),
		[Description]= ISNULL(@Description,Description),
		[Status]= ISNULL(@Status,Status),	
		[DateOfCreation]= ISNULL(@DateOfCreation,DateOfCreation),
		[DateOfModification]=ISNULL(@DateOfModification,DateOfModification)		
		WHERE [RegulationId] = @RegulationId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO


-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables RegulationDepartment
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateRegulationDepartment
(
	@RegulationId int,
	@DepartmentId varchar(50),
	@EmployeeAccess bit
)
AS
BEGIN
	BEGIN TRY
		UPDATE [RegulationDepartment] SET
		[EmployeeAccess]=ISNULL(@EmployeeAccess,EmployeeAccess)			
		WHERE [RegulationId] = @RegulationId AND [DepartmentId] = @DepartmentId
		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Update Tables Comment
-- ==============================================================================================================

CREATE PROCEDURE USP_UpdateComment
(
	@UserId varchar(50),
	@RegulationId int,
	@Acceptance bit,
	@Description varchar(255),
	@DateOfCreation date,
	@DateOfModification date
)
AS
BEGIN
	BEGIN TRY
		UPDATE [Comment] SET
		[Acceptance]=ISNULL(@Acceptance,Acceptance),
		[Description]=ISNULL(@Description,Description),
		[DateOfCreation]=ISNULL(@DateOfCreation,DateOfCreation),
		[DateOfModification]=ISNULL(@DateOfModification,DateOfModification)
		WHERE [UserId]=@UserId AND [RegulationId]=@RegulationId		
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO