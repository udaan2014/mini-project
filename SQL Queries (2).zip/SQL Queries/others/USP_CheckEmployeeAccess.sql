-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Checking the Regulations which are having the Employee Access
-- ==============================================================================================================    
CREATE PROCEDURE USP_CheckEmployeeAccess
(
	@UserId varchar(50)
)
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT RD.[RegulationId] FROM [RegulationDepartment]  AS RD WITH(NOLOCK) INNER JOIN [User] AS U 
			ON RD.[DepartmentId]= U.[DepartmentID] WHERE RD.[EmployeeAccess]=1	AND U.[UserId]=@UserId	
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   
