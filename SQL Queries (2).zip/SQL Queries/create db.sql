-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tricare database
-- ==============================================================================================================
CREATE DATABASE TricareDatabase
GO

USE TricareDatabase
GO

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables: User 
-- ==============================================================================================================
CREATE TABLE [User]
(
	[UserId] varchar(50),	
	[UserName] varchar(50),
	[Password] varchar(255),
	[RoleId] int,
	[DepartmentId] varchar(50),
	[DateOfJoining] date DEFAULT GETDATE(),
	[DateOfBirth] date,
	[EmailId] varchar(50),
	[Phonenumber] varchar(50),
	[Address] varchar(255),
	[SecretQuestion] varchar(255),
	CONSTRAINT PK_User_UserId PRIMARY KEY ([UserId])
)
GO

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables:  Department
-- ==============================================================================================================
CREATE TABLE [Department]
(
	[DepartmentId] varchar(50),
	[DepartmentName] varchar(50),
	[DateOfCreation] date DEFAULT GETDATE(), 
	CONSTRAINT PK_Department_DepartmentId PRIMARY KEY ([DepartmentId])
)
GO

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables Role
-- ==============================================================================================================
CREATE TABLE [Role]
(
	[RoleId] int IDENTITY(1,1),
	[RoleType] varchar(50),
	[Description] varchar(255),
	CONSTRAINT PK_Role_RoleId PRIMARY KEY ([RoleId])
)
GO

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables Regulation
-- ==============================================================================================================
CREATE TABLE [Regulation]
(
	[RegulationId] int IDENTITY(1,1),
	[RegulationName] varchar(50),
	[Description] varchar(255),
	[Status] varchar(50),
	[DateOfCreation] date DEFAULT GETDATE(),
	[DateOfModification] date DEFAULT GETDATE(),
	CONSTRAINT PK_Regulation_RegulationId PRIMARY KEY ([RegulationId])
)
GO
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Table RegulationDepartemnt
-- ==============================================================================================================

CREATE TABLE [RegulationDepartment]
(
	[RegulationId] int,
	[DepartmentId] varchar(50),
	[EmployeeAccess] bit,
	CONSTRAINT PK_RegulationDepartment_RegulationId_DepartmentId PRIMARY KEY ([RegulationId],[DepartmentId])
)
GO

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Tables Comment
-- ==============================================================================================================
CREATE TABLE [Comment]
(
	[UserId] varchar(50),
	[RegulationId] int,
	[Acceptance] bit,
	[Description] varchar(255),
	[DateOfCreation] date DEFAULT GETDATE(),
	[DateOfModification] date DEFAULT GETDATE(),
	CONSTRAINT PK_Comment_UserId_RegulationId PRIMARY KEY ([UserId],[RegulationId])
)

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Foreign keys for the tables
-- ==============================================================================================================
ALTER TABLE [User]
	ADD CONSTRAINT FK_User_Role_RoleId
	FOREIGN KEY (RoleId) REFERENCES [Role]([RoleId]) ON DELETE CASCADE 
GO

ALTER TABLE [User]
	ADD CONSTRAINT FK_User_Department_DepartmentId
	FOREIGN KEY (DepartmentId) REFERENCES [Department]([DepartmentId]) ON DELETE CASCADE 
GO

ALTER TABLE [RegulationDepartment]
	ADD CONSTRAINT FK_RegulationDepartment_Department_DepartmentId
	FOREIGN KEY (DepartmentId) REFERENCES [Department]([DepartmentId]) ON DELETE CASCADE 
GO

ALTER TABLE [RegulationDepartment]
	ADD CONSTRAINT FK_RegulationDepartment_Regulation_RegulationId
	FOREIGN KEY (RegulationId) REFERENCES [Regulation]([RegulationId]) ON DELETE CASCADE 
GO

ALTER TABLE [Comment]
	ADD CONSTRAINT FK_Comment_User_UserId
	FOREIGN KEY (UserId) REFERENCES [User]([UserId]) ON DELETE CASCADE 
GO

ALTER TABLE [Comment]
	ADD CONSTRAINT FK_Comment_Regulation_RegulationId
	FOREIGN KEY (RegulationId) REFERENCES [Regulation]([RegulationId]) ON DELETE CASCADE 
GO