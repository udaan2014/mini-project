
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in comment table
-- ==============================================================================================================     
CREATE PROCEDURE USP_AddComment
(
	@UserId varchar(50),
	@RegulationId int,
	@Acceptance bit,
	@Description varchar(255),
	@DateOfCreation date,
	@DateOfModification date
)
AS
BEGIN
	BEGIN TRY
		INSERT INTO [Comment]([UserId],[RegulationId],[Acceptance],[Description],[DateOfCreation],[DateOfModification])
		VALUES (@UserId,@RegulationId,@Acceptance,@Description,@DateOfCreation,@DateOfModification)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO     