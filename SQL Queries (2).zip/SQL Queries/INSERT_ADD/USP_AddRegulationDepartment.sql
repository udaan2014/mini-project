
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in RegulationDepartment table
-- ==============================================================================================================     
CREATE PROCEDURE USP_AddRegulationDepartment
(
	@RegulationId int,
	@DepartmentId varchar(50),
	@EmployeeAccess bit	
)
AS
BEGIN
	BEGIN TRY
		INSERT INTO [RegulationDepartment]([RegulationId],[DepartmentId],[EmployeeAccess])
		VALUES (@RegulationId,@DepartmentId,@EmployeeAccess)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO 
