-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Insertion in User Table
-- ==============================================================================================================         
CREATE PROCEDURE USP_AddUser
(
	--@UserId varchar(50),
	@UserName varchar(50),
	@Password varchar(255),	
	@RoleId int,
	@DepartmentId varchar(50),
	@DateOfJoining date,
	@DateOfBirth date,
	@EmailId varchar(50),
	@Phonenumber varchar(50),
	@Address varchar(255),
	@SecretQuestion varchar(255)
)
AS
BEGIN
	BEGIN TRY
		DECLARE @lastID varchar(50)
		DECLARE @userID varchar(50)
		DECLARE @UserId varchar(50)
		SET @lastID = ISNULL((SELECT MAX(UserId) FROM [User]), 'USR0000')
		SET @lastID= SUBSTRING(@lastID,4,4)		
		SET @userID=CAST(@lastID AS int) +1		
		SET @UserId='EMP' + RIGHT(('0000'+@userID),4)		
		
		INSERT INTO [User]([UserId],[UserName],[Password],[RoleId],[DepartmentId],[DateOfJoining],[DateOfBirth],[EmailId],[Phonenumber],[Address],[SecretQuestion])  
		VALUES (@UserId,@UserName,@Password,@RoleId,@DepartmentId,@DateOfJoining,@DateOfBirth,@EmailId,@Phonenumber,@Address,@SecretQuestion)
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO