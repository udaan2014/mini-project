-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from user table
-- ==============================================================================================================    
CREATE PROCEDURE USP_SelectUserData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [UserId],
				[UserName],
				[Password],
				[RoleId],
				[DepartmentId],
				[DateOfJoining],
				[DateOfBirth],
				[EmailId],
				[Phonenumber],
				[Address],
				[SecretQuestion]
		FROM [User]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   


-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from department table
-- ==============================================================================================================    
CREATE PROCEDURE USP_SelectDepartmentData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [DepartmentId],
				[DepartmentName],
				[DateOfCreation] 
		FROM [Department]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from Role table
-- ==============================================================================================================    
CREATE PROCEDURE USP_SelectRoleData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [RoleId],
				[RoleType],
				[Description] 
		FROM [Role]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from regulation table
-- ==============================================================================================================    
CREATE PROCEDURE USP_SelectRegulationData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [RegulationId],
				[RegulationName],
				[Description],
				[Status],
				[DateOfCreation],
				[DateOfModification] 
		FROM [Regulation]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   
-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from RegulationDepartment table
-- ==============================================================================================================    
CREATE PROCEDURE USP_SelectRegulationDepartmentData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [RegulationId],
				[DepartmentId],
				[EmployeeAccess] 
		FROM [RegulationDepartment]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   

-- ==============================================================================================================
-- Author : Aromita Sen (666114)
-- Created On : 2-1-2018
-- Description: Query for Creating Store Procedure for Selecting Rows from Comment table
-- ==============================================================================================================    
CREATE PROCEDURE USP_SelectCommentData
AS
BEGIN
	BEGIN TRY
		SET NOCOUNT ON;		
		SELECT [UserId],
				[RegulationId],
				[Acceptance],
				[Description],
				[DateOfCreation],
				[DateOfModification] 
		FROM [Comment]  
	END TRY
	BEGIN CATCH
		SELECT ERROR_MESSAGE()
	END CATCH
END
GO   